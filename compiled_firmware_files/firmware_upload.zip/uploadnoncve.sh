#/bin/bash
fwfile="firmware.bin"
porta=$(ls /dev/tty.usbserial-*)
baud="460800"
esptool="~/.platformio/packages/tool-esptoolpy/esptool.py"

$esptool \
--chip esp32 --port $porta --baud $baud --before default_reset --after hard_reset write_flash -z \
--flash_mode dio --flash_freq 80m --flash_size detect \
0xe000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/boot_app0.bin \
0x1000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/bootloader.bin \
0x10000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/$fwfile \
0x8000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/partitions.bin

