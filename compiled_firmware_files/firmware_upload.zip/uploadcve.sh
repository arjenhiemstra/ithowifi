#/bin/bash
fwfile="firmware.bin"
esptool="/Users/arjen/.platformio/packages/tool-esptoolpy/esptool.py"
#portb="/dev/cu.SLAB_USBtoUART1"
porta=$(ls /dev/tty.usbserial-*)

findespStart='$esptool --chip esp32 --port '
findespEnd=' --baud 115200 read_mac'

$esptool --chip esp32 --port $porta --baud 921600 read_mac

ret=$?
if [[ $ret == 0 ]]; then
	echo "*** It's there, lets flash!"
else
	echo "*** iNo ESP32 found!"
#	porta=$portb
#	$esptool --chip esp32 --port $porta --baud 921600 read_mac
#	ret=$?
#	if [[ $ret == 0 ]]; then
#		echo "*** It's there, lets flash!"
#	fi	
fi


echo "flashing ESP32"
$esptool --chip esp32 --port $porta --baud 921600 --before default_reset \
--after hard_reset write_flash -z --flash_mode dio --flash_freq keep --flash_size detect \
0xe000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/boot_app0.bin \
0x1000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/bootloader.bin \
0x10000 ~/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/$fwfile \
0x8000 ~arjen/ownCloud/SoftwareDevelopment/ithowifi/compiled_firmware_files/upload/partitions.bin
ret=$?
if [[ $ret == 0 ]]; then
	echo "*** Succes!\n"
else
	echo "*** ESP32 not flashed!"
fi 
